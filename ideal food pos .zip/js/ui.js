/* =========================
   UI Rendering Functions
   ========================= */

function renderCategories(){
  const wrap = $("#categories"); wrap.innerHTML = "";
  const prodSel = $("#prodCategory"), dealSel = $("#dealCategory"), cProdSel = $("#cProdCategory");
  if(prodSel) prodSel.innerHTML = "";
  if(dealSel) dealSel.innerHTML = "";
  if(cProdSel) cProdSel.innerHTML = "";

  categories.forEach(cat => {
    const b = document.createElement('button'); b.className = 'cat-btn';
    if (cat === currentCategory) b.style.opacity = 0.85;
    b.textContent = cat;
    b.onclick = () => { currentCategory = cat; $("#searchInput").value = ""; renderCategories(); renderProducts(); };
    wrap.appendChild(b);

    if (cat !== "All Items"){
      if (prodSel){ const o=document.createElement('option'); o.value=cat; o.textContent=cat; prodSel.appendChild(o); }
      if (dealSel){ const o=document.createElement('option'); o.value=cat; o.textContent=cat; dealSel.appendChild(o); }
      if (cProdSel){ const o=document.createElement('option'); o.value=cat; o.textContent=cat; cProdSel.appendChild(o); }
    }
  });
}

function productMatches(p){
  const q = ($("#searchInput")?.value || "").trim().toLowerCase();
  const inCat = (currentCategory === "All Items") || (p.category === currentCategory);
  const inSearch = !q || (p.name||"").toLowerCase().includes(q) || (p.category||"").toLowerCase().includes(q);
  return inCat && inSearch;
}

function dealMatches(d){
  const q = ($("#searchInput")?.value || "").trim().toLowerCase();
  const inCat = (currentCategory === "All Items") || (d.category === currentCategory);
  const inSearch = !q || (d.name||"").toLowerCase().includes(q) || (d.items && d.items.some(it => (it.name||"").toLowerCase().includes(q)));
  return inCat && inSearch;
}

function loadImageToImgTag(p, imgEl){
  if(!p || !p.img) return;
  if (String(p.img).startsWith('idb://')){
    const id = Number(p.img.replace('idb://',''));
    idbGetImage(id).then(blob => {
      if (!blob) { imgEl.alt = 'No Image'; return; }
      const url = URL.createObjectURL(blob);
      imgEl.src = url;
    }).catch(err => {
      console.warn('loadImageToImgTag failed', err);
      imgEl.alt = 'No Image';
    });
  } else if (String(p.img).startsWith('data:') || String(p.img).startsWith('http') || String(p.img).startsWith('/')){
    imgEl.src = p.img;
  } else {
    imgEl.alt = 'No Image';
  }
}

function renderProducts(){
  const cont = $("#products"); cont.innerHTML = "";

  products.forEach((p, i) => {
    if (!productMatches(p)) return;
    if (!Array.isArray(p.priceList)) p.priceList = [];
    if (!p.price) p.price = { small:0, medium:0, large:0 };

    const card = document.createElement('div'); card.className = 'product-card';
    const imgTag = document.createElement('img');
    if (p.img){
      imgTag.alt = 'Loading...';
      loadImageToImgTag(p, imgTag);
    } else {
      imgTag.alt = 'No Image';
      imgTag.style.background = '#eee';
    }

    const title = document.createElement('div'); title.style.fontWeight='700'; title.textContent = p.name || '';
    const muted = document.createElement('div'); muted.className='muted'; muted.textContent = p.category || '';
    card.appendChild(imgTag);
    card.appendChild(title);
    card.appendChild(muted);

    const row = document.createElement('div'); row.className = 'size-row';

    if (p.priceList && p.priceList.length > 0){
      p.priceList.forEach(pl => {
        if(!pl || isNaN(pl.price) || pl.price <= 0) return;
        const btn = document.createElement('button');
        btn.textContent = `${pl.label} Rs ${money(pl.price)}`;
        btn.onclick = () => addToBill(p.name, pl.label, Number(pl.price));
        row.appendChild(btn);
      });
    } else {
      if (Number(p.price.small) > 0){
        const b = document.createElement('button'); b.textContent = `S  ${money(p.price.small)}`; b.onclick = () => addToBill(p.name, 'Small', Number(p.price.small)); row.appendChild(b);
      }
      if (Number(p.price.medium) > 0){
        const b = document.createElement('button'); b.textContent = `M  ${money(p.price.medium)}`; b.onclick = () => addToBill(p.name, 'Medium', Number(p.price.medium)); row.appendChild(b);
      }
      if (Number(p.price.large) > 0){
        const b = document.createElement('button'); b.textContent = `L  ${money(p.price.large)}`; b.onclick = () => addToBill(p.name, 'Large', Number(p.price.large)); row.appendChild(b);
      }
    }

    if (row.children.length > 0) card.appendChild(row);

    const editWrap = document.createElement('div'); editWrap.style.marginTop='6px';
    if (p.priceList && p.priceList.length > 0){
      const btn = document.createElement('button'); btn.className='btn edit-custom'; btn.textContent='✏ '; btn.onclick = () => openEditCustomProduct(i); editWrap.appendChild(btn);
    } else {
      const btn = document.createElement('button'); btn.className='btn edit-fixed'; btn.textContent='✏'; btn.onclick = () => openEditProduct(i); editWrap.appendChild(btn);
    }
    card.appendChild(editWrap);

    cont.appendChild(card);
  });

  deals.filter(dealMatches).forEach(d => {
    const card = document.createElement('div'); card.className = 'product-card';
    const itemsText = (d.items||[]).map(it => `${it.name}${it.size?` (${it.size})`:''}`).join(", ");
    const title = document.createElement('div'); title.style.fontWeight='700'; title.textContent = d.name || '';
    const muted = document.createElement('div'); muted.className='muted'; muted.textContent = `Deal: ${itemsText}`;
    card.appendChild(title); card.appendChild(muted);
    const btnRow = document.createElement('div'); btnRow.style.display='flex'; btnRow.style.justifyContent='center'; btnRow.style.gap='8px'; btnRow.style.marginTop='8px';
    const addBtn = document.createElement('button'); addBtn.className='btn brand'; addBtn.textContent=`Rs ${money(d.price)}`; addBtn.onclick = ()=> addDealToBill(d.name);
    const editBtn = document.createElement('button'); editBtn.className='btn edit-deal'; editBtn.textContent='✏ '; editBtn.onclick = ()=> openDealEditor(d.name);
    btnRow.appendChild(addBtn); btnRow.appendChild(editBtn);
    card.appendChild(btnRow);
    cont.appendChild(card);
  });

  if (cont.children.length === 0) cont.innerHTML = '<div class="muted" style="padding:12px">No products or deals found for this search/category.</div>';
}

/* =========================
   Invoice number handling
   ========================= */
function getNextInvoiceNumber() {
  let maxInvoice = 0;
  historyData.forEach(entry => {
    if (entry.invoice) {
      const num = parseInt(entry.invoice.replace(/\D/g, ''));
      if (!isNaN(num) && num > maxInvoice) {
        maxInvoice = num;
      }
    }
  });
  
  const nextNum = Math.max(maxInvoice + 1, invoiceCounter);
  invoiceCounter = nextNum + 1;
  lsSet(LS_KEYS.INVOICE_COUNTER, invoiceCounter);
  
  return String(nextNum).padStart(4, '0');
}

/* =========================
   Sales Tracking
   ========================= */
function adjustSalesForEntry(entry, multiplier = 1){
  if (!entry || !entry.items || !entry.paid) return;
  
  const dayKey = entry.paymentDate || dayKeyFromTimestamp(entry.timestamp || Date.now());
  if (!salesData || typeof salesData !== 'object') salesData = {};
  if (!salesData[dayKey]) salesData[dayKey] = { categories: {}, special: {} };
  
  let nonCokeTotal = 0;
  entry.items.forEach(it => {
    if (!it.name.toLowerCase().includes('coke')) {
      nonCokeTotal += (Number(it.qty) || 0) * (Number(it.price) || 0);
    }
  });
  
  const discountAmount = Math.round(nonCokeTotal * ((entry.discount || 0) / 100));
  
  // Process items and group by category
  entry.items.forEach(it => {
    const name = it.name || 'Unknown';
    const value = (Number(it.qty) || 0) * (Number(it.price) || 0);
    if (value <= 0) return;
    
    // Find product category
    let category = "Uncategorized";
    const product = products.find(p => p.name === name);
    if (product && product.category) {
      category = product.category;
    } else {
      // Check if it's a deal
      const deal = deals.find(d => d.name === name);
      if (deal && deal.category) {
        category = deal.category;
      }
    }
    
    // Initialize category if not exists
    if (!salesData[dayKey].categories[category]) {
      salesData[dayKey].categories[category] = {};
    }
    
    // Add to category item
    salesData[dayKey].categories[category][name] = (salesData[dayKey].categories[category][name] || 0) + multiplier * value;
    
    // Remove if zero or negative
    if (salesData[dayKey].categories[category][name] <= 0) {
      delete salesData[dayKey].categories[category][name];
    }
    
    // Remove empty category
    if (Object.keys(salesData[dayKey].categories[category]).length === 0) {
      delete salesData[dayKey].categories[category];
    }
  });
  
  // Handle Discount (as negative amount)
  if (discountAmount > 0) {
    salesData[dayKey].special["Discount"] = (salesData[dayKey].special["Discount"] || 0) - multiplier * discountAmount;
  }
  
  // Handle Delivery Charge
  if (entry.deliveryCharge && entry.deliveryCharge > 0) {
    salesData[dayKey].special["Delivery Charge"] = (salesData[dayKey].special["Delivery Charge"] || 0) + multiplier * entry.deliveryCharge;
  }
  
  // Clean up zero values in special
  Object.keys(salesData[dayKey].special || {}).forEach(key => {
    if (Math.abs(salesData[dayKey].special[key]) < 0.01) delete salesData[dayKey].special[key];
  });
  
  // Clean up empty special object
  if (Object.keys(salesData[dayKey].special || {}).length === 0) {
    delete salesData[dayKey].special;
  }
  
  // Keep only last 365 days
  try {
    const keys = Object.keys(salesData).sort().reverse();
    const keep = new Set(keys.slice(0, 365));
    const newSales = {};
    keys.forEach(k => { if (keep.has(k)) newSales[k] = salesData[k]; });
    salesData = newSales;
  } catch(e) { console.warn('sales prune failed', e); }
  
  lsSet(LS_KEYS.SALES, salesData);
}

function recordSales(items, discountPercent, deliveryCharge){
  if (!items || !items.length) return;
  const entry = { items, discount: discountPercent, deliveryCharge, timestamp: Date.now() };
  adjustSalesForEntry(entry, +1);
}