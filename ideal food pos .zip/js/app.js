/* =========================
   App state
   ========================= */
let ca/* =========================
   App state
   ========================= */
let categories = lsGetSync(LS_KEYS.CATEGORIES, seedCategories.slice());
let products = lsGetSync(LS_KEYS.PRODUCTS, seedProducts.slice());
let deals = lsGetSync(LS_KEYS.DEALS, []);
let historyData = lsGetSync(LS_KEYS.HISTORY, []);
let addressBook = lsGetSync(LS_KEYS.ADDRESS_BOOK, { byName: {}, byPhone: {} });
let salesData = lsGetSync(LS_KEYS.SALES, {});
let invoiceCounter = lsGetSync(LS_KEYS.INVOICE_COUNTER, Math.max(1, historyData.length + 1));
let deletionLog = lsGetSync(LS_KEYS.DELETION_LOG, []);

let bill = [];
let currentCategory = "All Items";
let orderType = "";
let adminLoggedIn = false;

let editingIndex = null;
let editingOriginalEntry = null;
let currentPaymentIndex = null;
let currentDeleteIndex = null;

/* =========================
   Bill operations with Coke exclusion for discount
   ========================= */
function addToBill(name, size, price){
  const found = bill.find(x => x.name === name && x.size === size && x.price === price);
  if (found) found.qty += 1; else bill.push({ name, size, price, qty:1 });
  updateBill();
}

function addDealToBill(dealName){
  const d = deals.find(x => x.name === dealName); if(!d) return;
  const found = bill.find(x => x.name === d.name && x.size === 'Deal');
  if (found) found.qty += 1; else bill.push({ name: d.name, size: 'Deal', price: d.price, qty:1 });
  updateBill();
}

function changeQty(idx, delta){
  if (!bill[idx]) return;
  bill[idx].qty += delta;
  if (bill[idx].qty <= 0) bill.splice(idx,1);
  updateBill();
}

function removeLine(idx){ bill.splice(idx,1); updateBill(); }

function updateBill(){
  const box = $("#billItems"); box.innerHTML = '';
  if (!bill.length){ box.innerHTML = '<div class="muted">No items yet — add products from the left.</div>'; $("#totalAmount").textContent = '0'; return; }
  let itemsTotal = 0;
  let nonCokeTotal = 0;
  
  bill.forEach((it, idx) => {
    const lineTotal = it.qty * it.price;
    itemsTotal += lineTotal;
    
    if (!it.name.toLowerCase().includes('coke')) {
      nonCokeTotal += lineTotal;
    }
    
    const row = document.createElement('div');
    row.style.display = 'grid'; row.style.gridTemplateColumns = '1fr 90px 80px 30px'; row.style.alignItems='center'; row.style.gap='8px'; row.style.padding='6px 0'; row.style.borderBottom='1px dashed #eee';
    row.innerHTML = `<div><strong>${escapeHtml(it.name)}</strong><div class="muted">${escapeHtml(it.size)}</div></div>
      <div style="text-align:center"><button class="btn light" onclick="changeQty(${idx},-1)">-</button><span style="padding:0 8px">${it.qty}</span><button class="btn light" onclick="changeQty(${idx},1)">+</button></div>
      <div style="text-align:right">Rs ${money(lineTotal)}</div>
      <div style="text-align:center"><button class="btn light" onclick="removeLine(${idx})">×</button></div>`;
    box.appendChild(row);
  });

  const discount = Number($("#discount")?.value) || 0;
  const delivery = Number($("#deliveryCharge")?.value) || 0;
  
  const discountAmt = Math.round(nonCokeTotal * (discount / 100));
  const finalTotal = Math.max(0, Math.round(itemsTotal - discountAmt + delivery));
  
  $("#totalAmount").textContent = money(finalTotal);
}

/* =========================
   Edit product / custom product flows
   ========================= */
function openEditProduct(index){
  const p = products[index]; if(!p) return;
  const modal = $("#editModal");
  modal.innerHTML = `
    <h3>Edit Prices — ${escapeHtml(p.name)}</h3>
    <div class="muted">Leave blank to keep current price.</div>
    <input id="editSmall" type="number" placeholder="Small price" value="${p.price?.small ?? ''}">
    <input id="editMedium" type="number" placeholder="Medium price" value="${p.price?.medium ?? ''}">
    <input id="editLarge" type="number" placeholder="Large price" value="${p.price?.large ?? ''}">
    <div style="display:flex;justify-content:flex-end;gap:8px">
      <button class="btn green" onclick="saveEditProduct(${index})">Save</button>
      <button class="btn light" onclick="closeEditModal()">Cancel</button>
    </div>
  `;
  $("#modalBackdrop").style.display = 'flex';
}

function saveEditProduct(index){
  const p = products[index]; if(!p) return;
  const sRaw = $("#editSmall")?.value, mRaw = $("#editMedium")?.value, lRaw = $("#editLarge")?.value;
  p.price = {
    small: (sRaw === "" || sRaw == null) ? (p.price?.small || 0) : parseFloat(sRaw),
    medium: (mRaw === "" || mRaw == null) ? (p.price?.medium || 0) : parseFloat(mRaw),
    large: (lRaw === "" || lRaw == null) ? (p.price?.large || 0) : parseFloat(lRaw)
  };
  products[index] = p;
  lsSet(LS_KEYS.PRODUCTS, products);
  renderProducts(); populateAdminSelects(); closeEditModal();
}

function openEditCustomProduct(index){
  const p = products[index]; if(!p) return;
  const modal = $("#editModal");
  let rows = "";
  (p.priceList || []).forEach((pl,i) => {
    rows += `<div style="display:flex;gap:8px;margin-bottom:6px">
      <input id="editLabel${i}" placeholder="Label (e.g. 500ml or 200)" value="${escapeHtml(pl.label)}">
      <input id="editPrice${i}" type="number" placeholder="Price" min="0" value="${pl.price}">
    </div>`;
  });
  rows += `<div style="display:flex;gap:8px;margin-bottom:6px">
    <input id="newLabel" placeholder="New label (or price)">
    <input id="newPrice" type="number" placeholder="New price" min="0">
  </div>`;
  modal.innerHTML = `<h3>Edit Custom Prices — ${escapeHtml(p.name)}</h3><div class="muted">Edit existing rows or add a new one. Label can be numeric or text.</div>${rows}
    <div style="display:flex;justify-content:flex-end;gap:8px">
      <button class="btn green" onclick="saveEditCustomProduct(${index})">Save</button>
      <button class="btn light" onclick="closeEditModal()">Cancel</button>
    </div>`;
  $("#modalBackdrop").style.display = 'flex';
}

function saveEditCustomProduct(index){
  const p = products[index]; if(!p) return;
  const newList = [];
  for(let i=0;i < (p.priceList?.length || 0); i++){
    const label = $("#editLabel"+i)?.value?.trim();
    const price = Number($("#editPrice"+i)?.value);
    if(label && !isNaN(price) && price > 0) newList.push({ label, price });
  }
  const newLabel = $("#newLabel")?.value?.trim();
  const newPrice = Number($("#newPrice")?.value);
  if (newLabel && !isNaN(newPrice) && newPrice > 0) newList.push({ label: newLabel, price: Math.round(newPrice) });

  if (newList.length === 0){
    if (!confirm("No custom prices left — product will have no price buttons. Continue?")) return;
  }

  products[index].priceList = newList;
  lsSet(LS_KEYS.PRODUCTS, products);
  renderProducts(); populateAdminSelects(); closeEditModal();
}

function closeEditModal(){ $("#modalBackdrop").style.display = 'none'; $("#editModal").innerHTML = ''; }

/* =========================
   Add / edit products & deals
   ========================= */
function addProduct(){
  const name = $("#prodName")?.value?.trim();
  const cat = $("#prodCategory")?.value;
  const small = Number($("#priceSmall")?.value) || 0;
  const medium = Number($("#priceMedium")?.value) || 0;
  const large = Number($("#priceLarge")?.value) || 0;
  const imgInput = $("#prodImg");
  if (!name) return alert("Product name required");
  if (!cat) return alert("Category required");
  const newProd = { name, category: cat, price: { small, medium, large }, img: "", priceList: [] };
  if (imgInput && imgInput.files && imgInput.files[0]) {
    const file = imgInput.files[0];
    idbPutImage(file).then(id => {
      newProd.img = 'idb://' + id;
      products.push(newProd);
      lsSet(LS_KEYS.PRODUCTS, products);
      renderProducts(); populateAdminSelects();
      $("#prodName").value=''; $("#priceSmall").value=''; $("#priceMedium").value=''; $("#priceLarge").value=''; imgInput.value='';
    }).catch(err => {
      console.error('idbPutImage failed', err);
      const reader = new FileReader();
      reader.onload = e => {
        newProd.img = e.target.result;
        products.push(newProd); lsSet(LS_KEYS.PRODUCTS, products); renderProducts(); populateAdminSelects();
      };
      reader.readAsDataURL(file);
    });
  } else {
    products.push(newProd); lsSet(LS_KEYS.PRODUCTS, products); renderProducts(); populateAdminSelects();
    $("#prodName").value=''; $("#priceSmall").value=''; $("#priceMedium").value=''; $("#priceLarge").value=''; if (imgInput) imgInput.value='';
  }
}

function addCustomProduct(){
  const name = $("#cProdName")?.value?.trim();
  const cat = $("#cProdCategory")?.value;
  const imgInput = $("#cProdImg");
  if (!name) return alert("Product name required");
  if (!cat) return alert("Category required");
  const raw = [ $("#cPrice1")?.value, $("#cPrice2")?.value, $("#cPrice3")?.value ];
  const priceList = [];
  raw.forEach(v => {
    if (!v) return;
    const s = String(v).trim();
    if (s.includes('-')){
      const parts = s.split('-'); const price = Number(parts[parts.length-1]); const label = parts.slice(0,parts.length-1).join('-').trim();
      if (label && !isNaN(price) && price > 0) priceList.push({ label, price: Math.round(price) });
    } else {
      const num = Number(s);
      if (!isNaN(num) && num > 0) priceList.push({ label: String(Math.round(num)), price: Math.round(num) });
    }
  });
  if (!priceList.length) return alert("Enter at least one valid price (e.g. 200 or 500ml-200)");
  const newProd = { name, category: cat, img: "", price: { small:0, medium:0, large:0 }, priceList };
  if(imgInput && imgInput.files && imgInput.files[0]){
    const file = imgInput.files[0];
    idbPutImage(file).then(id => {
      newProd.img = 'idb://' + id;
      products.push(newProd); lsSet(LS_KEYS.PRODUCTS, products); renderProducts(); populateAdminSelects();
      $("#cProdName").value=''; $("#cPrice1").value=''; $("#cPrice2").value=''; $("#cPrice3").value=''; imgInput.value='';
    }).catch(err => {
      console.error('idbPutImage failed', err);
      const reader = new FileReader();
      reader.onload = e => {
        newProd.img = e.target.result;
        products.push(newProd); lsSet(LS_KEYS.PRODUCTS, products); renderProducts(); populateAdminSelects();
      };
      reader.readAsDataURL(file);
    });
  } else {
    products.push(newProd); lsSet(LS_KEYS.PRODUCTS, products); renderProducts(); populateAdminSelects();
    $("#cProdName").value=''; $("#cPrice1").value=''; $("#cPrice2").value=''; $("#cPrice3").value=''; if(imgInput) imgInput.value='';
  }
}

function addDeal(){
  const name = $("#dealName")?.value?.trim();
  const itemsRaw = $("#dealItems")?.value?.trim();
  const cat = $("#dealCategory")?.value;
  const price = Number($("#dealPrice")?.value) || 0;
  if (!name) return alert("Deal name required");
  if (!itemsRaw) return alert("Deal items required");
  if (!cat) return alert("Category required");
  if (price <= 0) return alert("Deal price required");
  const items = itemsRaw.split(/\r?\n|,/).map(s=>s.trim()).filter(Boolean).map(line=>{
    const colon = line.split(':'); if (colon.length>=2) return { name: colon[0].trim(), size: colon.slice(1).join(':').trim() };
    const m = line.match(/^(.*)\s*\((.*)\)$/); if (m) return { name: m[1].trim(), size: m[2].trim() };
    return { name: line.trim() };
  });
  if (!items.length) return alert("No items parsed");
  deals.push({ name, items, price, category: cat }); lsSet(LS_KEYS.DEALS, deals); renderProducts(); populateAdminSelects();
  $("#dealName").value=''; $("#dealItems").value=''; $("#dealPrice").value='';
}

/* =========================
   Deal editor functions
   ========================= */
let editingDealName = null;

function openDealEditor(dealName){
  editingDealName = dealName;
  const d = deals.find(x=>x.name === dealName);
  if(!d){ alert("Deal not found."); return; }
  document.getElementById('deal-editor-title').textContent = `Edit Deal — ${d.name || ''}`;
  document.getElementById('deal-editor-name').value = d.name || '';
  document.getElementById('deal-editor-price').value = (d.price != null) ? d.price : '';
  const itemsText = (d.items || []).map(it => it.size ? `${it.name}:${it.size}` : `${it.name}`).join("\n");
  document.getElementById('deal-editor-items').value = itemsText;
  document.getElementById('deal-editor').style.display = 'flex';
}

function closeDealEditor(){ document.getElementById('deal-editor').style.display = 'none'; editingDealName = null; }

function saveDealEditor(){
  if(!editingDealName) return;
  const name = document.getElementById('deal-editor-name').value.trim();
  const priceVal = document.getElementById('deal-editor-price').value.trim();
  const itemsRaw = document.getElementById('deal-editor-items').value.trim();
  if(!name){ alert('Deal name cannot be empty.'); return; }
  const price = priceVal === '' ? null : parseFloat(priceVal);
  if(priceVal !== '' && isNaN(price)){ alert('Please enter a valid numeric price.'); return; }
  const items = itemsRaw ? _parseDealItemsText(itemsRaw) : [];
  const idx = deals.findIndex(x => x.name === editingDealName);
  if(idx === -1){ alert('Deal not found (it may have been renamed).'); closeDealEditor(); return; }
  if(name !== editingDealName && deals.some((d, i) => d.name === name && i !== idx)){
    if(!confirm('Another deal with this name already exists. Rename anyway?')) return;
  }
  deals[idx].name = name;
  if(price !== null) deals[idx].price = price;
  deals[idx].items = items;
  lsSet(LS_KEYS.DEALS, deals);
  renderProducts();
  populateAdminSelects();
  closeDealEditor();
  alert('Deal updated.');
}

function _parseDealItemsText(itemsStr){
  const lines = itemsStr.split(/\r?\n|,/).map(s => s.trim()).filter(Boolean);
  const items = lines.map(line => {
    const colon = line.split(':');
    if(colon.length >= 2){
      return { name: colon[0].trim(), size: colon.slice(1).join(':').trim() };
    }
    const m = line.match(/^(.*)\s*\((.*)\)\s*$/);
    if(m) return { name: m[1].trim(), size: m[2].trim() };
    return { name: line.trim() };
  });
  return items.filter(x => x.name);
}

/* =========================
   PRINT & SAVE BILL - ALL BILLS SAVED AS UNPAID BY DEFAULT
   ========================= */
function getNextInvoiceAndSave(){
  const invStr = getNextInvoiceNumber();
  return invStr;
}

function saveCustomerToAddressBook(name, phone, address, deliveryCharge){
  if (!name) return;
  addressBook.byName = addressBook.byName || {};
  addressBook.byPhone = addressBook.byPhone || {};
  addressBook.byName[name] = { phone: phone || "", address: address || "", deliveryCharge: Number(deliveryCharge) || 0 };
  if (phone) addressBook.byPhone[phone] = name;
  lsSet(LS_KEYS.ADDRESS_BOOK, addressBook);
}

function printBill(){
  if (!bill || bill.length === 0) return alert("No items in bill!");

  if ($("#discount").value === "" || $("#discount").value == null) $("#discount").value = "0";

  const customerName = $("#customerName").value.trim();
  const customerPhone = $("#customerPhone").value.trim();
  const customerAddress = $("#customerAddress").value.trim();
  const discountPercent = Number($("#discount").value) || 0;
  const deliveryCharge = Number($("#deliveryCharge")?.value) || 0;
  const customerNote = $("#customerNote").value.trim();

  let itemsTotal = 0;
  let nonCokeTotal = 0;
  bill.forEach(it => {
    const lineTotal = it.qty * it.price;
    itemsTotal += lineTotal;
    if (!it.name.toLowerCase().includes('coke')) {
      nonCokeTotal += lineTotal;
    }
  });
  
  const discountAmount = Math.round(nonCokeTotal * discountPercent / 100);
  const finalTotal = Math.round(itemsTotal - discountAmount + deliveryCharge);

  const now = Date.now();
  const invoiceForThis = (editingIndex !== null && historyData[editingIndex] && historyData[editingIndex].invoice) ? historyData[editingIndex].invoice : getNextInvoiceAndSave();

  if (editingIndex !== null && historyData[editingIndex]){
    try {
      if (editingOriginalEntry && editingOriginalEntry.paid) {
        adjustSalesForEntry(editingOriginalEntry, -1);
      }
    } catch (e) { console.warn('Failed to subtract original sales during edit', e); }

    const wasPaid = historyData[editingIndex].paid;
    historyData[editingIndex] = {
      customerName,
      customerPhone,
      customerAddress,
      customerNote,
      orderType,
      items: JSON.parse(JSON.stringify(bill)),
      total: finalTotal,
      discount: discountPercent,
      discountAmount,
      deliveryCharge,
      paid: wasPaid,
      timestamp: now,
      invoice: invoiceForThis
    };
    lsSet(LS_KEYS.HISTORY, historyData);

    if (wasPaid) {
      try { recordSales(bill, discountPercent, deliveryCharge); } catch (e) { console.warn("recordSales failed on edit", e); }
    }

    editingIndex = null;
    editingOriginalEntry = null;
  } else {
    const newEntry = {
      customerName,
      customerPhone,
      customerAddress,
      customerNote,
      orderType,
      items: JSON.parse(JSON.stringify(bill)),
      total: finalTotal,
      discount: discountPercent,
      discountAmount,
      deliveryCharge,
      paid: false,
      timestamp: now,
      invoice: invoiceForThis
    };
    historyData.push(newEntry);
    lsSet(LS_KEYS.HISTORY, historyData);

    if (orderType === "Delivery" && deliveryCharge > 0) {
      saveCustomerToAddressBook(customerName, customerPhone, customerAddress, deliveryCharge);
    }
  }

  if (customerName){
    saveCustomerToAddressBook(customerName, customerPhone, customerAddress, deliveryCharge);
  }

  renderHistory();
  populateAdminSelects();

  const nameHTML = customerName ? `<div>Customer Name: ${escapeHtml(customerName)}</div>` : "";
  const phoneHTML = customerPhone ? `<div>Phone: ${escapeHtml(customerPhone)}</div>` : "";
  const addressHTML = customerAddress ? `<div>Address: ${escapeHtml(customerAddress)}</div>` : "";
  const discountHTML = discountAmount > 0 ? `<div>Discount: ${money(discountPercent)}% (Rs ${money(discountAmount)})</div>` : "";
  const deliveryHTML = deliveryCharge > 0 ? `<div>Delivery: Rs ${money(deliveryCharge)}</div>` : "";
  const noteHTML = customerNote ? `<div>Note: ${escapeHtml(customerNote)}</div>` : "";
  
  const statusHTML = `<div style="text-align:center;color:#dc3545;font-weight:bold;margin:8px 0">UNPAID BILL</div>`;

  const itemsHtml = bill.map(item => {
    const desc = `${item.name}${item.size && item.size !== 'Deal' ? ' (' + item.size + ')' : ''}`;
    const qty = Number(item.qty);
    const price = Number(item.qty) * Number(item.price);
    return `<tr>
      <td style="padding:3px 0">${escapeHtml(desc)}</td>
      <td style="width:40px;text-align:center;padding:3px 0">${qty}</td>
      <td style="width:80px;text-align:right;padding:3px 0">${money(price)}</td>
    </tr>`;
  }).join("");

  const dateStr = formatDate(now);
  const timeStr = formatTime(now);

  const printContent = `
  <html>
  <head>
    <title>Receipt</title>
    <style>
      @page { size: 80mm auto; margin: 5mm; }
      body { font-family: monospace; font-size: 12px; margin: 0; color:#000; }
      .center { text-align: center; font-weight: bold; }
      .line { border-top: 1px dashed #000; margin: 6px 0; }
      table { width: 100%; border-collapse: collapse; }
      td { padding: 3px 0; vertical-align: top; }
      .right { text-align: right; }
      .bold { font-weight: bold; }
      .unpaid { color: #dc3545; font-weight: bold; text-align: center; margin: 8px 0; }
    </style>
  </head>
  <body>
    <div class="center">IDEAL FOOD</div>
    <div class="center">03166102586</div>
    <div class="center">03069826144</div>
    <div class="center">Invoice: ${escapeHtml(invoiceForThis)}</div>
    <div class="center">${escapeHtml(dateStr)} ${escapeHtml(timeStr)}</div>
    <div class="line"></div>
    ${nameHTML}
    ${phoneHTML}
    ${addressHTML}
    ${noteHTML}
    <div>Order Type: ${escapeHtml(orderType || '')}</div>
    <div class="line"></div>
    <table>
      <tr class="bold"><td>DESCRIPTION</td><td style="width:40px;text-align:center">QTY</td><td style="width:8