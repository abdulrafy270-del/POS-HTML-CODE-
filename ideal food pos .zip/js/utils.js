/* =========================
   Helpers & formatting
   ========================= */
const $ = sel => document.querySelector(sel);
const $$ = sel => Array.from(document.querySelectorAll(sel));

function money(n){ return Number(n||0).toFixed(0); }
function escapeHtml(s){ return String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }

function pad(n, digits=2){ return String(n).padStart(digits,'0'); }
function formatDate(ts){
  const d = (ts ? new Date(ts) : new Date());
  return `${pad(d.getDate(),2)}/${pad(d.getMonth()+1,2)}/${d.getFullYear()}`;
}
function formatTime(ts){
  const d = (ts ? new Date(ts) : new Date());
  return `${pad(d.getHours(),2)}:${pad(d.getMinutes(),2)}:${pad(d.getSeconds(),2)}`;
}
function dayKeyFromTimestamp(ts){ return new Date(ts).toISOString().slice(0,10); }

/* =========================
   File upload helper
   ========================= */
function handleFileUpload(input, productIndex){
  const file = input.files && input.files[0];
  if(!file) return;
  idbPutImage(file).then(id => {
    products[productIndex].img = 'idb://' + id;
    lsSet(LS_KEYS.PRODUCTS, products);
    renderProducts();
  }).catch(err => {
    console.error('handleFileUpload idbPutImage failed', err);
    const reader = new FileReader();
    reader.onload = e => {
      products[productIndex].img = e.target.result;
      lsSet(LS_KEYS.PRODUCTS, products);
      renderProducts();
    };
    reader.readAsDataURL(file);
  });
}

function dataURLToBlob(dataURL) {
  const parts = dataURL.split(',');
  const mime = parts[0].match(/:(.*?);/)[1];
  const bstr = atob(parts[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new Blob([u8arr], { type: mime });
}