# Ideal Food POS System

A modern Point of Sale (POS) system for restaurant/food businesses with offline capabilities, image storage, and comprehensive sales tracking.

## Features

### Core Features
- **Product Management**: Add, edit, and categorize products with fixed or custom pricing
- **Deal Management**: Create combo deals with multiple items
- **Bill Creation**: Add items to bill, adjust quantities, apply discounts
- **Customer Management**: Save customer details, phone numbers, and delivery addresses
- **Order Types**: Dine-in, Takeaway, and Delivery options
- **Print Receipts**: Generate printable receipts with business details

### Advanced Features
- **Offline Storage**: Uses IndexedDB for image storage with localStorage fallback
- **Sales Tracking**: Daily sales reports with category-wise breakdown
- **Discount Handling**: Apply discounts excluding "Coke" items from discount calculation
- **Payment Collection**: Mark bills as paid/unpaid, track payment amounts
- **Bill History**: View, edit, print, and delete previous bills
- **Admin Panel**: Secure admin login for product/category management
- **Deletion Log**: Track deleted bills with reasons

### Security Features
- Admin login protection
- Deletion confirmation with reason requirement
- Sales data protection

## Setup Instructions

1. Simply open `index.html` in a modern web browser
2. No server required - works completely offline
3. All data is stored locally in the browser

## Default Admin Credentials
- Username: `admin`
- Password: `1234`

## File Structure
