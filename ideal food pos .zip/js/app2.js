/* =========================
   App state
   ========================= */
let categories = lsGetSync(LS_KEYS.CATEGORIES, seedCategories.slice());
let products = lsGetSync(LS_KEYS.PRODUCTS, seedProducts.slice());
let deals = lsGetSync(LS_KEYS.DEALS, []);
let historyData = lsGetSync(LS_KEYS.HISTORY, []);
let addressBook = lsGetSync(LS_KEYS.ADDRESS_BOOK, { byName: {}, byPhone: {} });
let salesData = lsGetSync(LS_KEYS.SALES, {});
let invoiceCounter = lsGetSync(LS_KEYS.INVOICE_COUNTER, Math.max(1, historyData.length + 1));
let deletionLog = lsGetSync(LS_KEYS.DELETION_LOG, []);

let bill = [];
let currentCategory = "All Items";
let orderType = "";
let adminLoggedIn = false;

let editingIndex = null;
let editingOriginalEntry = null;
let currentPaymentIndex = null;
let currentDeleteIndex = null;

/* =========================
   Bill operations with Coke exclusion for discount
   ========================= */
function addToBill(name, size, price){
  const found = bill.find(x => x.name === name && x.size === size && x.price === price);
  if (found) found.qty += 1; else bill.push({ name, size, price, qty:1 });
  updateBill();
}

function addDealToBill(dealName){
  const d = deals.find(x => x.name === dealName); if(!d) return;
  const found = bill.find(x => x.name === d.name && x.size === 'Deal');
  if (found) found.qty += 1; else bill.push({ name: d.name, size: 'Deal', price: d.price, qty:1 });
  updateBill();
}

function changeQty(idx, delta){
  if (!bill[idx]) return;
  bill[idx].qty += delta;
  if (bill[idx].qty <= 0) bill.splice(idx,1);
  updateBill();
}

function removeLine(idx){ bill.splice(idx,1); updateBill(); }

function updateBill(){
  const box = $("#billItems"); box.innerHTML = '';
  if (!bill.length){ box.innerHTML = '<div class="muted">No items yet — add products from the left.</div>'; $("#totalAmount").textContent = '0'; return; }
  let itemsTotal = 0;
  let nonCokeTotal = 0;
  
  bill.forEach((it, idx) => {
    const lineTotal = it.qty * it.price;
    itemsTotal += lineTotal;
    
    if (!it.name.toLowerCase().includes('coke')) {
      nonCokeTotal += lineTotal;
    }
    
    const row = document.createElement('div');
    row.style.display = 'grid'; row.style.gridTemplateColumns = '1fr 90px 80px 30px'; row.style.alignItems='center'; row.style.gap='8px'; row.style.padding='6px 0'; row.style.borderBottom='1px dashed #eee';
    row.innerHTML = `<div><strong>${escapeHtml(it.name)}</strong><div class="muted">${escapeHtml(it.size)}</div></div>
      <div style="text-align:center"><button class="btn light" onclick="changeQty(${idx},-1)">-</button><span style="padding:0 8px">${it.qty}</span><button class="btn light" onclick="changeQty(${idx},1)">+</button></div>
      <div style="text-align:right">Rs ${money(lineTotal)}</div>
      <div style="text-align:center"><button class="btn light" onclick="removeLine(${idx})">×</button></div>`;
    box.appendChild(row);
  });

  const discount = Number($("#discount")?.value) || 0;
  const delivery = Number($("#deliveryCharge")?.value) || 0;
  
  const discountAmt = Math.round(nonCokeTotal * (discount / 100));
  const finalTotal = Math.max(0, Math.round(itemsTotal - discountAmt + delivery));
  
  $("#totalAmount").textContent = money(finalTotal);
}

/* =========================
   Edit product / custom product flows
   ========================= */
function openEditProduct(index){
  const p = products[index]; if(!p) return;
  const modal = $("#editModal");
  modal.innerHTML = `
    <h3>Edit Prices — ${escapeHtml(p.name)}</h3>
    <div class="muted">Leave blank to keep current price.</div>
    <input id="editSmall" type="number" placeholder="Small price" value="${p.price?.small ?? ''}">
    <input id="editMedium" type="number" placeholder="Medium price" value="${p.price?.medium ?? ''}">
    <input id="editLarge" type="number" placeholder="Large price" value="${p.price?.large ?? ''}">
    <div style="display:flex;justify-content:flex-end;gap:8px">
      <button class="btn green" onclick="saveEditProduct(${index})">Save</button>
      <button class="btn light" onclick="closeEditModal()">Cancel</button>
    </div>
  `;
  $("#modalBackdrop").style.display = 'flex';
}

function saveEditProduct(index){
  const p = products[index]; if(!p) return;
  const sRaw = $("#editSmall")?.value, mRaw = $("#editMedium")?.value, lRaw = $("#editLarge")?.value;
  p.price = {
    small: (sRaw === "" || sRaw == null) ? (p.price?.small || 0) : parseFloat(sRaw),
    medium: (mRaw === "" || mRaw == null) ? (p.price?.medium || 0) : parseFloat(mRaw),
    large: (lRaw === "" || lRaw == null) ? (p.price?.large || 0) : parseFloat(lRaw)
  };
  products[index] = p;
  lsSet(LS_KEYS.PRODUCTS, products);
  renderProducts(); populateAdminSelects(); closeEditModal();
}

function openEditCustomProduct(index){
  const p = products[index]; if(!p) return;
  const modal = $("#editModal");
  let rows = "";
  (p.priceList || []).forEach((pl,i) => {
    rows += `<div style="display:flex;gap:8px;margin-bottom:6px">
      <input id="editLabel${i}" placeholder="Label (e.g. 500ml or 200)" value="${escapeHtml(pl.label)}">
      <input id="editPrice${i}" type="number" placeholder="Price" min="0" value="${pl.price}">
    </div>`;
  });
  rows += `<div style="display:flex;gap:8px;margin-bottom:6px">
    <input id="newLabel" placeholder="New label (or price)">
    <input id="newPrice" type="number" placeholder="New price" min="0">
  </div>`;
  modal.innerHTML = `<h3>Edit Custom Prices — ${escapeHtml(p.name)}</h3><div class="muted">Edit existing rows or add a new one. Label can be numeric or text.</div>${rows}
    <div style="display:flex;justify-content:flex-end;gap:8px">
      <button class="btn green" onclick="saveEditCustomProduct(${index})">Save</button>
      <button class="btn light" onclick="closeEditModal()">Cancel</button>
    </div>`;
  $("#modalBackdrop").style.display = 'flex';
}

function saveEditCustomProduct(index){
  const p = products[index]; if(!p) return;
  const newList = [];
  for(let i=0;i < (p.priceList?.length || 0); i++){
    const label = $("#editLabel"+i)?.value?.trim();
    const price = Number($("#editPrice"+i)?.value);
    if(label && !isNaN(price) && price > 0) newList.push({ label, price });
  }
  const newLabel = $("#newLabel")?.value?.trim();
  const newPrice = Number($("#newPrice")?.value);
  if (newLabel && !isNaN(newPrice) && newPrice > 0) newList.push({ label: newLabel, price: Math.round(newPrice) });

  if (newList.length === 0){
    if (!confirm("No custom prices left — product will have no price buttons. Continue?")) return;
  }

  products[index].priceList = newList;
  lsSet(LS_KEYS.PRODUCTS, products);
  renderProducts(); populateAdminSelects(); closeEditModal();
}

function closeEditModal(){ $("#modalBackdrop").style.display = 'none'; $("#editModal").innerHTML = ''; }

/* =========================
   Add / edit products & deals
   ========================= */
function addProduct(){
  const name = $("#prodName")?.value?.trim();
  const cat = $("#prodCategory")?.value;
  const small = Number($("#priceSmall")?.value) || 0;
  const medium = Number($("#priceMedium")?.value) || 0;
  const large = Number($("#priceLarge")?.value) || 0;
  const imgInput = $("#prodImg");
  if (!name) return alert("Product name required");
  if (!cat) return alert("Category required");
  const newProd = { name, category: cat, price: { small, medium, large }, img: "", priceList: [] };
  if (imgInput && imgInput.files && imgInput.files[0]) {
    const file = imgInput.files[0];
    idbPutImage(file).then(id => {
      newProd.img = 'idb://' + id;
      products.push(newProd);
      lsSet(LS_KEYS.PRODUCTS, products);
      renderProducts(); populateAdminSelects();
      $("#prodName").value=''; $("#priceSmall").value=''; $("#priceMedium").value=''; $("#priceLarge").value=''; imgInput.value='';
    }).catch(err => {
      console.error('idbPutImage failed', err);
      const reader = new FileReader();
      reader.onload = e => {
        newProd.img = e.target.result;
        products.push(newProd); lsSet(LS_KEYS.PRODUCTS, products); renderProducts(); populateAdminSelects();
      };
      reader.readAsDataURL(file);
    });
  } else {
    products.push(newProd); lsSet(LS_KEYS.PRODUCTS, products); renderProducts(); populateAdminSelects();
    $("#prodName").value=''; $("#priceSmall").value=''; $("#priceMedium").value=''; $("#priceLarge").value=''; if (imgInput) imgInput.value='';
  }
}

function addCustomProduct(){
  const name = $("#cProdName")?.value?.trim();
  const cat = $("#cProdCategory")?.value;
  const imgInput = $("#cProdImg");
  if (!name) return alert("Product name required");
  if (!cat) return alert("Category required");
  const raw = [ $("#cPrice1")?.value, $("#cPrice2")?.value, $("#cPrice3")?.value ];
  const priceList = [];
  raw.forEach(v => {
    if (!v) return;
    const s = String(v).trim();
    if (s.includes('-')){
      const parts = s.split('-'); const price = Number(parts[parts.length-1]); const label = parts.slice(0,parts.length-1).join('-').trim();
      if (label && !isNaN(price) && price > 0) priceList.push({ label, price: Math.round(price) });
    } else {
      const num = Number(s);
      if (!isNaN(num) && num > 0) priceList.push({ label: String(Math.round(num)), price: Math.round(num) });
    }
  });
  if (!priceList.length) return alert("Enter at least one valid price (e.g. 200 or 500ml-200)");
  const newProd = { name, category: cat, img: "", price: { small:0, medium:0, large:0 }, priceList };
  if(imgInput && imgInput.files && imgInput.files[0]){
    const file = imgInput.files[0];
    idbPutImage(file).then(id => {
      newProd.img = 'idb://' + id;
      products.push(newProd); lsSet(LS_KEYS.PRODUCTS, products); renderProducts(); populateAdminSelects();
      $("#cProdName").value=''; $("#cPrice1").value=''; $("#cPrice2").value=''; $("#cPrice3").value=''; imgInput.value='';
    }).catch(err => {
      console.error('idbPutImage failed', err);
      const reader = new FileReader();
      reader.onload = e => {
        newProd.img = e.target.result;
        products.push(newProd); lsSet(LS_KEYS.PRODUCTS, products); renderProducts(); populateAdminSelects();
      };
      reader.readAsDataURL(file);
    });
  } else {
    products.push(newProd); lsSet(LS_KEYS.PRODUCTS, products); renderProducts(); populateAdminSelects();
    $("#cProdName").value=''; $("#cPrice1").value=''; $("#cPrice2").value=''; $("#cPrice3").value=''; if(imgInput) imgInput.value='';
  }
}

function addDeal(){
  const name = $("#dealName")?.value?.trim();
  const itemsRaw = $("#dealItems")?.value?.trim();
  const cat = $("#dealCategory")?.value;
  const price = Number($("#dealPrice")?.value) || 0;
  if (!name) return alert("Deal name required");
  if (!itemsRaw) return alert("Deal items required");
  if (!cat) return alert("Category required");
  if (price <= 0) return alert("Deal price required");
  const items = itemsRaw.split(/\r?\n|,/).map(s=>s.trim()).filter(Boolean).map(line=>{
    const colon = line.split(':'); if (colon.length>=2) return { name: colon[0].trim(), size: colon.slice(1).join(':').trim() };
    const m = line.match(/^(.*)\s*\((.*)\)$/); if (m) return { name: m[1].trim(), size: m[2].trim() };
    return { name: line.trim() };
  });
  if (!items.length) return alert("No items parsed");
  deals.push({ name, items, price, category: cat }); lsSet(LS_KEYS.DEALS, deals); renderProducts(); populateAdminSelects();
  $("#dealName").value=''; $("#dealItems").value=''; $("#dealPrice").value='';
}

/* =========================
   Deal editor functions
   ========================= */
let editingDealName = null;

function openDealEditor(dealName){
  editingDealName = dealName;
  const d = deals.find(x=>x.name === dealName);
  if(!d){ alert("Deal not found."); return; }
  document.getElementById('deal-editor-title').textContent = `Edit Deal — ${d.name || ''}`;
  document.getElementById('deal-editor-name').value = d.name || '';
  document.getElementById('deal-editor-price').value = (d.price != null) ? d.price : '';
  const itemsText = (d.items || []).map(it => it.size ? `${it.name}:${it.size}` : `${it.name}`).join("\n");
  document.getElementById('deal-editor-items').value = itemsText;
  document.getElementById('deal-editor').style.display = 'flex';
}

function closeDealEditor(){ document.getElementById('deal-editor').style.display = 'none'; editingDealName = null; }

function saveDealEditor(){
  if(!editingDealName) return;
  const name = document.getElementById('deal-editor-name').value.trim();
  const priceVal = document.getElementById('deal-editor-price').value.trim();
  const itemsRaw = document.getElementById('deal-editor-items').value.trim();
  if(!name){ alert('Deal name cannot be empty.'); return; }
  const price = priceVal === '' ? null : parseFloat(priceVal);
  if(priceVal !== '' && isNaN(price)){ alert('Please enter a valid numeric price.'); return; }
  const items = itemsRaw ? _parseDealItemsText(itemsRaw) : [];
  const idx = deals.findIndex(x => x.name === editingDealName);
  if(idx === -1){ alert('Deal not found (it may have been renamed).'); closeDealEditor(); return; }
  if(name !== editingDealName && deals.some((d, i) => d.name === name && i !== idx)){
    if(!confirm('Another deal with this name already exists. Rename anyway?')) return;
  }
  deals[idx].name = name;
  if(price !== null) deals[idx].price = price;
  deals[idx].items = items;
  lsSet(LS_KEYS.DEALS, deals);
  renderProducts();
  populateAdminSelects();
  closeDealEditor();
  alert('Deal updated.');
}

function _parseDealItemsText(itemsStr){
  const lines = itemsStr.split(/\r?\n|,/).map(s => s.trim()).filter(Boolean);
  const items = lines.map(line => {
    const colon = line.split(':');
    if(colon.length >= 2){
      return { name: colon[0].trim(), size: colon.slice(1).join(':').trim() };
    }
    const m = line.match(/^(.*)\s*\((.*)\)\s*$/);
    if(m) return { name: m[1].trim(), size: m[2].trim() };
    return { name: line.trim() };
  });
  return items.filter(x => x.name);
}

/* =========================
   PRINT & SAVE BILL - ALL BILLS SAVED AS UNPAID BY DEFAULT
   ========================= */
function getNextInvoiceAndSave(){
  const invStr = getNextInvoiceNumber();
  return invStr;
}

function saveCustomerToAddressBook(name, phone, address, deliveryCharge){
  if (!name) return;
  addressBook.byName = addressBook.byName || {};
  addressBook.byPhone = addressBook.byPhone || {};
  addressBook.byName[name] = { phone: phone || "", address: address || "", deliveryCharge: Number(deliveryCharge) || 0 };
  if (phone) addressBook.byPhone[phone] = name;
  lsSet(LS_KEYS.ADDRESS_BOOK, addressBook);
}

function printBill(){
  if (!bill || bill.length === 0) return alert("No items in bill!");

  if ($("#discount").value === "" || $("#discount").value == null) $("#discount").value = "0";

  const customerName = $("#customerName").value.trim();
  const customerPhone = $("#customerPhone").value.trim();
  const customerAddress = $("#customerAddress").value.trim();
  const discountPercent = Number($("#discount").value) || 0;
  const deliveryCharge = Number($("#deliveryCharge")?.value) || 0;
  const customerNote = $("#customerNote").value.trim();

  let itemsTotal = 0;
  let nonCokeTotal = 0;
  bill.forEach(it => {
    const lineTotal = it.qty * it.price;
    itemsTotal += lineTotal;
    if (!it.name.toLowerCase().includes('coke')) {
      nonCokeTotal += lineTotal;
    }
  });
  
  const discountAmount = Math.round(nonCokeTotal * discountPercent / 100);
  const finalTotal = Math.round(itemsTotal - discountAmount + deliveryCharge);

  const now = Date.now();
  const invoiceForThis = (editingIndex !== null && historyData[editingIndex] && historyData[editingIndex].invoice) ? historyData[editingIndex].invoice : getNextInvoiceAndSave();

  if (editingIndex !== null && historyData[editingIndex]){
    try {
      if (editingOriginalEntry && editingOriginalEntry.paid) {
        adjustSalesForEntry(editingOriginalEntry, -1);
      }
    } catch (e) { console.warn('Failed to subtract original sales during edit', e); }

    const wasPaid = historyData[editingIndex].paid;
    historyData[editingIndex] = {
      customerName,
      customerPhone,
      customerAddress,
      customerNote,
      orderType,
      items: JSON.parse(JSON.stringify(bill)),
      total: finalTotal,
      discount: discountPercent,
      discountAmount,
      deliveryCharge,
      paid: wasPaid,
      timestamp: now,
      invoice: invoiceForThis
    };
    lsSet(LS_KEYS.HISTORY, historyData);

    if (wasPaid) {
      try { recordSales(bill, discountPercent, deliveryCharge); } catch (e) { console.warn("recordSales failed on edit", e); }
    }

    editingIndex = null;
    editingOriginalEntry = null;
  } else {
    const newEntry = {
      customerName,
      customerPhone,
      customerAddress,
      customerNote,
      orderType,
      items: JSON.parse(JSON.stringify(bill)),
      total: finalTotal,
      discount: discountPercent,
      discountAmount,
      deliveryCharge,
      paid: false,
      timestamp: now,
      invoice: invoiceForThis
    };
    historyData.push(newEntry);
    lsSet(LS_KEYS.HISTORY, historyData);

    if (orderType === "Delivery" && deliveryCharge > 0) {
      saveCustomerToAddressBook(customerName, customerPhone, customerAddress, deliveryCharge);
    }
  }

  if (customerName){
    saveCustomerToAddressBook(customerName, customerPhone, customerAddress, deliveryCharge);
  }

  renderHistory();
  populateAdminSelects();

  const nameHTML = customerName ? `<div>Customer Name: ${escapeHtml(customerName)}</div>` : "";
  const phoneHTML = customerPhone ? `<div>Phone: ${escapeHtml(customerPhone)}</div>` : "";
  const addressHTML = customerAddress ? `<div>Address: ${escapeHtml(customerAddress)}</div>` : "";
  const discountHTML = discountAmount > 0 ? `<div>Discount: ${money(discountPercent)}% (Rs ${money(discountAmount)})</div>` : "";
  const deliveryHTML = deliveryCharge > 0 ? `<div>Delivery: Rs ${money(deliveryCharge)}</div>` : "";
  const noteHTML = customerNote ? `<div>Note: ${escapeHtml(customerNote)}</div>` : "";
  
  const statusHTML = `<div style="text-align:center;color:#dc3545;font-weight:bold;margin:8px 0">UNPAID BILL</div>`;

  const itemsHtml = bill.map(item => {
    const desc = `${item.name}${item.size && item.size !== 'Deal' ? ' (' + item.size + ')' : ''}`;
    const qty = Number(item.qty);
    const price = Number(item.qty) * Number(item.price);
    return `<tr>
      <td style="padding:3px 0">${escapeHtml(desc)}</td>
      <td style="width:40px;text-align:center;padding:3px 0">${qty}</td>
      <td style="width:80px;text-align:right;padding:3px 0">${money(price)}</td>
    </tr>`;
  }).join("");

  const dateStr = formatDate(now);
  const timeStr = formatTime(now);

  const printContent = `
  <html>
  <head>
    <title>Receipt</title>
    <style>
      @page { size: 80mm auto; margin: 5mm; }
      body { font-family: monospace; font-size: 12px; margin: 0; color:#000; }
      .center { text-align: center; font-weight: bold; }
      .line { border-top: 1px dashed #000; margin: 6px 0; }
      table { width: 100%; border-collapse: collapse; }
      td { padding: 3px 0; vertical-align: top; }
    </style>
  </head>
  <body>
    <div class="center">IDEAL FOOD</div>
    <div class="center">Invoice: ${escapeHtml(entry.invoice || '')}</div>
    <div class="center">Bill â€” ${escapeHtml(dateStr)} ${escapeHtml(timeStr)}</div>
    <div class="line"></div>
    ${customerName}
    ${phone}
    ${addr}
    ${note}
    <div>Order Type: ${escapeHtml(entry.orderType || '')}</div>
    <div class="line"></div>
    <table>
      <tr><td>DESCRIPTION</td><td style="width:40px;text-align:center">QTY</td><td style="width:80px;text-align:right">PRICE</td></tr>
      ${itemsHtml}
    </table>
    <div class="line"></div>
    <div style="display:flex;justify-content:space-between"><div class="muted">Items Subtotal:</div><div>Rs ${money(itemsSubtotal)}</div></div>
    ${discountHTML}
    ${deliveryHTML}
    <div class="line"></div>
    <div style="display:flex;justify-content:space-between"><div><strong>TOTAL</strong></div><div><strong>Rs ${money(entry.total)}</strong></div></div>
    <div class="line"></div>
  </body>
  </html>
  `;

  const w = window.open("", "_blank");
  if (!w) return alert("Please allow pop-ups to print.");
  w.document.write(printContent);
  w.document.close();
  setTimeout(() => {
    try { w.focus(); w.print(); } catch(e) { console.warn('history print failed', e); }
    try { w.close(); } catch(e) {}
  }, 250);
}

/* =========================
   HISTORY RENDER - SHOW/HIDE BUTTONS BASED ON PAID STATUS
   ========================= */
function renderHistory(){
  const list = $("#historyList");
  list.innerHTML = "";

  if(!historyData || historyData.length === 0){
    list.innerHTML = '<div class="muted">No saved bills yet.</div>';
    return;
  }

  historyData.slice().reverse().forEach((h, revIdx) => {
    const originalIndex = historyData.length - 1 - revIdx;
    const card = document.createElement("div");
    card.style.border = "1px solid #eee";
    card.style.padding = "8px";
    card.style.marginBottom = "8px";
    card.style.borderRadius = "6px";

    const when = `${formatDate(h.timestamp)} ${formatTime(h.timestamp)}`;
    const itemsSummary = (h.items || []).slice(0, 2).map(it => `${it.name}${it.size?` (${it.size})`:''} x${it.qty}`).join(", ");
    const paidStatus = h.paid ? 
      `<span class="paid-badge">Paid</span>` : 
      `<span class="unpaid-badge">Unpaid</span>`;

    card.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div><strong>${escapeHtml(h.customerName || 'Customer')}</strong> <span class="muted">Invoice: ${escapeHtml(h.invoice || '')}</span></div>
        ${paidStatus}
      </div>
      <div class="muted" style="margin-top:4px">${escapeHtml(when)}</div>
      <div class="muted" style="margin-top:6px">${escapeHtml(itemsSummary)}${h.items.length > 2 ? '...' : ''}</div>
      <div style="font-weight:700;margin-top:6px">Total: Rs ${money(h.total)}</div>
    `;
    
    if (!h.paid) {
      const buttonContainer = document.createElement("div");
      buttonContainer.style.display = 'flex';
      buttonContainer.style.gap = '8px';
      buttonContainer.style.marginTop = '8px';
      buttonContainer.innerHTML = `
        <button class="btn blue" onclick="editBillFromHistory(${originalIndex})">Edit</button>
        <button class="btn light" onclick="printHistory(${originalIndex})">Print</button>
        <button class="btn green" onclick="openPaymentModal(${originalIndex})">Collect Payment</button>
        <button class="btn red" onclick="openDeleteReasonModal(${originalIndex})">Delete</button>
      `;
      card.appendChild(buttonContainer);
    } else {
      const messageDiv = document.createElement("div");
      messageDiv.className = "muted";
      messageDiv.style.marginTop = "8px";
      messageDiv.style.fontSize = "12px";
      messageDiv.textContent = "Bill is paid. No actions available.";
      card.appendChild(messageDiv);
    }
    
    list.appendChild(card);
  });
}

/* =========================
   Payment Modal Functions
   ========================= */
function openPaymentModal(index) {
  const entry = historyData[index];
  if (!entry) return;
  
  currentPaymentIndex = index;
  $("#paymentTotal").textContent = `Rs ${money(entry.total)}`;
  $("#amountGiven").value = "";
  $("#remainingAmount").textContent = `Rs ${money(entry.total)}`;
  $("#paymentModal").style.display = "flex";
  
  // Update the input event handler
  $("#amountGiven").oninput = function() {
    const given = Number(this.value) || 0;
    const total = entry.total;
    const remaining = given - total;
    $("#remainingAmount").textContent = `Rs ${money(Math.abs(remaining))} ${remaining >= 0 ? '(Change)' : '(Due)'}`;
    $("#remainingAmount").style.color = remaining >= 0 ? '#28a745' : '#dc3545';
  };
}

function closePaymentModal() {
  $("#paymentModal").style.display = "none";
  currentPaymentIndex = null;
}

function markAsPaid() {
  const index = currentPaymentIndex;
  if (index === null || !historyData[index]) return;
  
  const amountGiven = Number($("#amountGiven").value) || 0;
  const entry = historyData[index];
  
  // First, record sales for this entry
  try {
    adjustSalesForEntry({...entry, paid: true}, +1);
  } catch (e) {
    console.warn("Failed to adjust sales on payment", e);
  }
  
  // Update the entry
  historyData[index].paid = true;
  historyData[index].amountGiven = amountGiven;
  historyData[index].paymentTimestamp = Date.now();
  historyData[index].paymentDate = new Date().toISOString().slice(0, 10);
  
  lsSet(LS_KEYS.HISTORY, historyData);
  
  renderHistory();
  closePaymentModal();
  alert("Payment recorded successfully! Bill marked as paid.");
}

function markAsUnpaid(index) {
  if (!historyData[index]) return;
  
  if (!confirm("Mark this bill as unpaid? This will remove it from today's sales.")) return;
  
  const entry = historyData[index];
  historyData[index].paid = false;
  delete historyData[index].amountGiven;
  delete historyData[index].paymentTimestamp;
  delete historyData[index].paymentDate;
  
  lsSet(LS_KEYS.HISTORY, historyData);
  
  // Remove from sales
  try {
    adjustSalesForEntry({...entry, paid: true}, -1);
  } catch (e) {
    console.warn("Failed to adjust sales on mark as unpaid", e);
  }
  
  renderHistory();
  alert("Bill marked as unpaid.");
}

function editBillFromHistory(idx){
  const entry = historyData[idx];
  if(!entry) return alert("History item not found.");
  
  if (entry.paid) {
    return alert("Cannot edit paid bills. Mark as unpaid first.");
  }
  
  editingIndex = idx;
  editingOriginalEntry = JSON.parse(JSON.stringify(entry));
  bill = JSON.parse(JSON.stringify(entry.items || []));
  $("#customerName").value = entry.customerName || "";
  $("#customerPhone").value = entry.customerPhone || "";
  $("#customerAddress").value = entry.customerAddress || "";
  $("#customerNote").value = entry.customerNote || "";
  $("#discount").value = entry.discount || 0;
  $("#deliveryCharge").value = entry.deliveryCharge || 0;
  orderType = entry.orderType || "";
  if(orderType === "Delivery") $("#addressWrap").style.display = "block"; else $("#addressWrap").style.display = "none";
  updateBill();
  $("#historyDrawer").style.display = "none";
}

/* =========================
   Delete with Reason Modal
   ========================= */
function openDeleteReasonModal(index) {
  const entry = historyData[index];
  if (entry && entry.paid) {
    return alert("Cannot delete paid bills.");
  }
  
  currentDeleteIndex = index;
  $("#deleteReasonText").value = "";
  $("#deleteReasonModal").style.display = "flex";
}

function closeDeleteReasonModal() {
  $("#deleteReasonModal").style.display = "none";
  currentDeleteIndex = null;
}

function deleteWithReason() {
  const idx = currentDeleteIndex;
  const reason = $("#deleteReasonText").value.trim();
  
  if (!reason) {
    alert("Please provide a reason for deletion.");
    return;
  }
  
  if(!historyData[idx]) return;
  
  // Calculate total of the bill to be deleted
  let billTotal = historyData[idx].total || 0;
  
  const deletionEntry = {
    timestamp: Date.now(),
    historyIndex: idx,
    reason: reason,
    billData: historyData[idx],
    deletedBy: adminLoggedIn ? "admin" : "user",
    customerName: historyData[idx].customerName || "",
    invoiceNumber: historyData[idx].invoice || "",
    totalAmount: billTotal,
    paymentDate: historyData[idx].paymentDate || dayKeyFromTimestamp(historyData[idx].timestamp)
  };
  
  deletionLog.push(deletionEntry);
  lsSet(LS_KEYS.DELETION_LOG, deletionLog);
  
  try {
    adjustSalesForEntry(historyData[idx], -1);
  } catch (e) { console.warn('Failed subtracting sales on delete', e); }
  
  historyData.splice(idx, 1);
  lsSet(LS_KEYS.HISTORY, historyData);
  
  renderHistory();
  closeDeleteReasonModal();
  alert("Bill deleted with reason recorded.");
}

/* =========================
   Sales report (by day) with categories and deletion log
   ========================= */
function renderSalesReport(){
  const sel = $("#salesYearSel");
  let selectedDay = sel?.value;
  const allDays = Object.keys(salesData || {}).sort().reverse();
  if (!selectedDay) selectedDay = (allDays.length > 0) ? allDays[0] : (new Date().toISOString().slice(0,10));
  const box = $("#salesReport");
  box.innerHTML = `<div class="muted" style="font-weight:bold;margin-bottom:10px">Sales Report for ${selectedDay}</div>`;
  
  // Check if there's any sales data
  if (!salesData || !salesData[selectedDay] || (!salesData[selectedDay].categories && !salesData[selectedDay].special)){
    box.innerHTML += '<div class="muted">No sales recorded for this day.</div>';
  }
  
  // Process sales data by categories
  let grandTotal = 0;
  
  // Display categories if they exist
  if (salesData[selectedDay] && salesData[selectedDay].categories) {
    const categories = Object.keys(salesData[selectedDay].categories).sort();
    
    categories.forEach(category => {
      const catData = salesData[selectedDay].categories[category];
      const catItems = Object.entries(catData).sort((a,b) => Math.abs(b[1]) - Math.abs(a[1]));
      
      let categoryTotal = 0;
      catItems.forEach(([item, amount]) => {
        categoryTotal += amount;
      });
      grandTotal += categoryTotal;
      
      const catDiv = document.createElement('div');
      catDiv.style.marginTop = '12px';
      catDiv.style.border = '1px solid #eee';
      catDiv.style.borderRadius = '6px';
      catDiv.style.padding = '8px';
      catDiv.style.backgroundColor = '#f9f9f9';
      
      catDiv.innerHTML = `
        <div style="font-weight:bold;color:var(--brand-dark);margin-bottom:6px;display:flex;justify-content:space-between">
          <span>${escapeHtml(category)}</span>
          <span>Rs ${money(categoryTotal)}</span>
        </div>
        <div style="max-height:120px;overflow-y:auto;font-size:12px">
      `;
      
      catItems.forEach(([item, amount]) => {
        const row = document.createElement('div');
        row.style.display = 'flex';
        row.style.justifyContent = 'space-between';
        row.style.padding = '2px 0';
        row.style.borderBottom = '1px dashed #eee';
        row.innerHTML = `
          <div style="padding-left:8px">${escapeHtml(item)}</div>
          <div>Rs ${money(amount)}</div>
        `;
        catDiv.appendChild(row);
      });
      
      box.appendChild(catDiv);
    });
  }
  
  // Show special items (Discount, Delivery Charge)
  if (salesData[selectedDay] && salesData[selectedDay].special) {
    const specialDiv = document.createElement('div');
    specialDiv.style.marginTop = '15px';
    specialDiv.style.borderTop = '2px solid #ddd';
    specialDiv.style.paddingTop = '10px';
    
    Object.entries(salesData[selectedDay].special).forEach(([item, amount]) => {
      const row = document.createElement('div');
      row.style.display = 'flex';
      row.style.justifyContent = 'space-between';
      row.style.padding = '6px 0';
      row.style.fontWeight = 'bold';
      row.innerHTML = `
        <div style="color:${item === "Discount" ? '#dc3545' : '#17a2b8'}">
          ${escapeHtml(item)}
        </div>
        <div style="color:${item === "Discount" ? '#dc3545' : '#17a2b8'}">
          ${item === "Discount" ? '-' : ''}Rs ${money(Math.abs(amount))}
        </div>
      `;
      grandTotal += amount;
      specialDiv.appendChild(row);
    });
    
    if (specialDiv.children.length > 0) {
      box.appendChild(specialDiv);
    }
  }
  
  // Display Grand Total
  if (grandTotal !== 0) {
    const totalDiv = document.createElement('div');
    totalDiv.style.display = 'flex';
    totalDiv.style.justifyContent = 'space-between';
    totalDiv.style.padding = '10px 0';
    totalDiv.style.borderTop = '2px solid #222';
    totalDiv.style.marginTop = '15px';
    totalDiv.style.fontWeight = 'bold';
    totalDiv.style.fontSize = '14px';
    totalDiv.innerHTML = `
      <div>GRAND TOTAL:</div>
      <div>Rs ${money(grandTotal)}</div>
    `;
    box.appendChild(totalDiv);
  }
  
  // Show deletion log for the selected day
  const deletionsForDay = deletionLog.filter(entry => {
    return dayKeyFromTimestamp(entry.timestamp) === selectedDay;
  });
  
  if (deletionsForDay.length > 0) {
    const deletionDiv = document.createElement('div');
    deletionDiv.style.marginTop = '25px';
    deletionDiv.style.borderTop = '2px dashed #dc3545';
    deletionDiv.style.paddingTop = '15px';
    
    deletionDiv.innerHTML = `
      <div style="font-weight:bold;color:#dc3545;margin-bottom:8px;font-size:14px">ðŸ“‹ DELETED BILLS LOG</div>
      <div style="font-size:11px;color:#666;margin-bottom:12px">Deleted bills with reasons:</div>
    `;
    
    // Create deletion table
    const table = document.createElement('table');
    table.style.width = '100%';
    table.style.borderCollapse = 'collapse';
    table.style.fontSize = '11px';
    
    // Table header
    const thead = document.createElement('thead');
    thead.innerHTML = `
      <tr style="background:#f8f9fa;font-weight:bold">
        <th style="padding:6px;text-align:left;border-bottom:1px solid #ddd">Action</th>
        <th style="padding:6px;text-align:left;border-bottom:1px solid #ddd">Reason</th>
        <th style="padding:6px;text-align:right;border-bottom:1px solid #ddd">Amount</th>
      </tr>
    `;
    table.appendChild(thead);
    
    // Table body
    const tbody = document.createElement('tbody');
    let deletionTotal = 0;
    
    deletionsForDay.forEach((entry, index) => {
      const row = document.createElement('tr');
      row.style.borderBottom = '1px solid #eee';
      
      const action = entry.deletedBy === "admin" ? "ADMIN DELETE" : "DELETE";
      const reason = entry.reason || "No reason provided";
      const amount = entry.totalAmount || 0;
      deletionTotal += amount;
      
      row.innerHTML = `
        <td style="padding:6px;color:#dc3545;font-weight:bold;font-size:10px">${action}</td>
        <td style="padding:6px">${escapeHtml(reason.length > 30 ? reason.substring(0, 30) + '...' : reason)}</td>
        <td style="padding:6px;text-align:right;color:#dc3545;font-weight:bold">Rs ${money(amount)}</td>
      `;
      tbody.appendChild(row);
    });
  table.appendChild(tbody);
    deletionDiv.appendChild(table);
    
    // Deletion total
    if (deletionsForDay.length > 0) {
      const totalRow = document.createElement('div');
      totalRow.style.display = 'flex';
      totalRow.style.justifyContent = 'space-between';
      totalRow.style.padding = '8px 0';
      totalRow.style.borderTop = '1px solid #dc3545';
      totalRow.style.marginTop = '8px';
      totalRow.style.fontWeight = 'bold';
      totalRow.style.color = '#dc3545';
      totalRow.style.fontSize = '12px';
      totalRow.innerHTML = `
        <div>Total Deleted Amount:</div>
        <div>Rs ${money(deletionTotal)}</div>
      `;
      deletionDiv.appendChild(totalRow);
      
      // Add info about number of deletions
      const infoDiv = document.createElement('div');
      infoDiv.style.fontSize = '10px';
      infoDiv.style.color = '#999';
      infoDiv.style.marginTop = '5px';
      infoDiv.style.textAlign = 'center';
      infoDiv.textContent = `${deletionsForDay.length} bill${deletionsForDay.length > 1 ? 's' : ''} deleted`;
      deletionDiv.appendChild(infoDiv);
    }
    
    box.appendChild(deletionDiv);
  }
}

/* =========================
   Admin helpers & selects
   ========================= */
function populateAdminSelects(){
  const removeCategorySel = $("#removeCategorySel"), removeProductSel = $("#removeProductSel"), removeDealSel = $("#removeDealSel");
  if (removeCategorySel) { removeCategorySel.innerHTML=''; categories.filter(c=>c!=="All Items").forEach(c=>{ const o=document.createElement('option'); o.value=c; o.textContent=c; removeCategorySel.appendChild(o); }); }
  if (removeProductSel) { removeProductSel.innerHTML=''; products.forEach((p,i)=>{ const o=document.createElement('option'); o.value=i; o.textContent=p.name; removeProductSel.appendChild(o); }); }
  if (removeDealSel) { removeDealSel.innerHTML=''; deals.forEach((d,i)=>{ const o=document.createElement('option'); o.value=i; o.textContent=d.name; removeDealSel.appendChild(o); }); }

  if (removeCategorySel) $("#removeCategoryBtn").disabled = (removeCategorySel.options.length===0);
  if (removeProductSel) $("#removeProductBtn").disabled = (removeProductSel.options.length===0);
  if (removeDealSel) $("#removeDealBtn").disabled = (removeDealSel.options.length===0);

  const sSel = $("#salesYearSel");
  if (sSel){
    sSel.innerHTML = "";
    const days = Object.keys(salesData || {}).sort().reverse();
    if (days.length === 0) {
      const now = new Date();
      for (let i=0;i<7;i++){
        const d = new Date(now); d.setDate(now.getDate() - i);
        const key = d.toISOString().slice(0,10);
        const o = document.createElement('option'); o.value = key; o.textContent = key; sSel.appendChild(o);
      }
    } else {
      days.forEach(day => { const o=document.createElement('option'); o.value = day; o.textContent = day; sSel.appendChild(o); });
    }
  }
}

/* =========================
   Admin actions
   ========================= */
function addCategory(){ const name = $("#newCategory").value.trim(); if(!name) return alert("Category name required"); if(categories.includes(name)) return alert("Already exists"); categories.push(name); lsSet(LS_KEYS.CATEGORIES, categories); renderCategories(); populateAdminSelects(); $("#newCategory").value=''; }
function removeCategory(){ const c = $("#removeCategorySel").value; if(!c) return alert("Select category"); if(!confirm(`Remove ${c} and all its products/deals?`)) return; categories = categories.filter(x=>x!==c); products = products.filter(p=>p.category!==c); deals = deals.filter(d=>d.category!==c); lsSet(LS_KEYS.CATEGORIES, categories); lsSet(LS_KEYS.PRODUCTS, products); lsSet(LS_KEYS.DEALS, deals); renderCategories(); renderProducts(); populateAdminSelects(); }
function removeProduct(){ const idx = Number($("#removeProductSel").value); if(isNaN(idx)) return alert("Select product"); if(!confirm("Remove product?")) return; products.splice(idx,1); lsSet(LS_KEYS.PRODUCTS, products); renderProducts(); populateAdminSelects(); }
function removeDeal(){ const idx = Number($("#removeDealSel").value); if(isNaN(idx)) return alert("Select deal"); if(!confirm("Remove deal?")) return; deals.splice(idx,1); lsSet(LS_KEYS.DEALS, deals); renderProducts(); populateAdminSelects(); }

/* =========================
   Admin login
   ========================= */
function adminLogin(){
  const user = $("#adminName").value.trim(), pass = $("#adminPass").value;
  if (user === 'admin' && pass === '1234'){
    adminLoggedIn = true; $("#adminLogin").style.display = 'none'; $("#adminControls").style.display = 'block'; $("#adminMsg").textContent=''; populateAdminSelects(); renderSalesReport();
    const delBtn = $("#deleteSalesBtn"); if (delBtn) delBtn.style.display = 'block';
    const pdBtn = $("#printDeleteSalesBtn"); if (pdBtn) pdBtn.style.display = 'block';
  } else { $("#adminMsg").textContent = 'Invalid credentials'; }
}

function adminLogout(){ adminLoggedIn = false; $("#adminLogin").style.display = 'block'; $("#adminControls").style.display = 'none'; $("#adminName").value=''; $("#adminPass").value=''; 
  const delBtn = $("#deleteSalesBtn"); if (delBtn) delBtn.style.display = 'none';
  const pdBtn = $("#printDeleteSalesBtn"); if (pdBtn) pdBtn.style.display = 'none';
}

/* =========================
   Delete Sales & History
   ========================= */
function deleteSalesAndHistory(){
  if (!adminLoggedIn) return alert("Admin login required.");
  if (!confirm("This will PERMANENTLY DELETE all saved bill history AND daily sales records. THIS CANNOT BE UNDONE. Type 'DELETE' to confirm.")) {
    if (!confirm("Are you sure you want to proceed?")) return;
  }
  const typed = prompt("To confirm permanent deletion, type DELETE (in uppercase):");
  if (!typed || typed.trim() !== "DELETE") return alert("Deletion cancelled (confirmation not provided).");

  try {
    historyData = [];
    salesData = {};
    lsSet(LS_KEYS.HISTORY, historyData);
    lsSet(LS_KEYS.SALES, salesData);

    invoiceCounter = 1;
    lsSet(LS_KEYS.INVOICE_COUNTER, invoiceCounter);

    renderHistory();
    renderSalesReport();
    populateAdminSelects();

    alert("All saved bill history and daily sales records were deleted. Invoice counter reset to 0001.");
  } catch (e) {
    console.error("deleteSalesAndHistory failed", e);
    alert("Delete failed. See console for details.");
  }
}

/* =========================
   Print & Delete Sales
   ========================= */
function printAndDeleteSales(){
  if (!adminLoggedIn) return alert("Admin login required.");

  const sel = $("#salesYearSel");
  const selectedDay = sel?.value || (new Date().toISOString().slice(0,10));
  
  // Get sales data for the selected day
  const dayData = salesData[selectedDay] || {};
  const categories = dayData.categories || {};
  const special = dayData.special || {};
  
  if (!confirm(`This will PRINT the sales report for ${selectedDay} and then PERMANENTLY DELETE all saved bill history and daily sales records. This cannot be undone.`)) return;
  const typed = prompt("To confirm, type DELETE (uppercase):");
  if (!typed || typed.trim() !== "DELETE") return alert("Cancelled â€” confirmation not provided.");

  const now = new Date();
  const printedAt = now.toLocaleString();
  let bodyHtml = `<div style="text-align:center;font-family:monospace"><h3>Sales Report</h3><div>${escapeHtml(selectedDay)}</div><div style="margin-bottom:8px">${escapeHtml(printedAt)}</div><hr></div>`;

  if (Object.keys(categories).length === 0 && Object.keys(special).length === 0){
    bodyHtml += `<div style="font-family:monospace">No sales recorded for ${escapeHtml(selectedDay)}.</div>`;
  } else {
    // Add categories
    Object.keys(categories).sort().forEach(category => {
      const catData = categories[category];
      bodyHtml += `<div style="font-family:monospace;margin-top:10px;font-weight:bold">${escapeHtml(category)}</div>`;
      Object.entries(catData).forEach(([item, amount]) => {
        bodyHtml += `<div style="font-family:monospace;display:flex;justify-content:space-between">
          <div style="padding-left:10px">${escapeHtml(item)}</div>
          <div>Rs ${money(amount)}</div>
        </div>`;
      });
    });
    
    // Add special items
    if (Object.keys(special).length > 0) {
      bodyHtml += `<div style="font-family:monospace;margin-top:10px;border-top:1px dashed #000;padding-top:10px">`;
      Object.entries(special).forEach(([item, amount]) => {
        bodyHtml += `<div style="font-family:monospace;display:flex;justify-content:space-between;font-weight:bold;color:${item === "Discount" ? '#dc3545' : '#17a2b8'}">
          <div>${escapeHtml(item)}</div>
          <div>${item === "Discount" ? '-' : ''}Rs ${money(Math.abs(amount))}</div>
        </div>`;
      });
      bodyHtml += `</div>`;
    }
    
    // Calculate and add total
    let total = 0;
    Object.values(categories).forEach(cat => {
      Object.values(cat).forEach(amount => total += amount);
    });
    Object.values(special).forEach(amount => total += amount);
    
    bodyHtml += `<hr><div style="display:flex;justify-content:space-between;font-family:monospace;font-weight:bold;margin-top:10px"><div>Total</div><div>Rs ${money(total)}</div></div>`;
  }

  const printContent = `<!doctype html><html><head><meta charset="utf-8"><title>Sales Report ${selectedDay}</title>
    <style>
      @page { size: 80mm auto; margin: 5mm; }
      body { font-family: monospace; font-size: 11px; color:#000; margin:6px; }
    </style></head><body>${bodyHtml}</body></html>`;

  const w = window.open("", "_blank");
  if (!w) return alert("Please allow pop-ups to print.");
  w.document.write(printContent);
  w.document.close();

  setTimeout(() => {
    try {
      w.focus();
      w.print();
      try { w.close(); } catch(e){}
    } catch (e) {
      console.warn("Print call failed:", e);
    }

    try {
      historyData = [];
      salesData = {};
      lsSet(LS_KEYS.HISTORY, historyData);
      lsSet(LS_KEYS.SALES, salesData);

      invoiceCounter = 1;
      lsSet(LS_KEYS.INVOICE_COUNTER, invoiceCounter);

      renderHistory();
      renderSalesReport();
      populateAdminSelects();

      alert(`Sales printed for ${selectedDay} and all saved bill history & sales records have been deleted. Invoice counter reset to 0001.`);
    } catch (e) {
      console.error("printAndDeleteSales deletion failed:", e);
      alert("Print succeeded but deletion failed â€” check console.");
    }
  }, 300);
}

/* =========================
   Wiring & initialization
   ========================= */
window.addEventListener('load', async () => {
  try {
    if (!categories || categories.length === 0) categories = seedCategories.slice();
    renderCategories(); renderProducts(); renderHistory(); populateAdminSelects();

    try {
      await idbOpen();
      for (let i=0;i<products.length;i++){
        const p = products[i];
        if (p && p.img && String(p.img).startsWith('data:')){
          if (String(p.img).length > 30000){
            try {
              const blob = dataURLToBlob(p.img);
              const id = await idbPutImage(blob);
              products[i].img = 'idb://' + id;
              console.log('Migrated product image to IndexedDB id', id, 'for', products[i].name);
            } catch (e) {
              console.warn('Failed migrating image for product', p.name, e);
            }
          }
        }
      }
      lsSet(LS_KEYS.PRODUCTS, products);

      await loadMetaFromIDB();

      renderCategories(); renderProducts(); renderHistory(); populateAdminSelects();

    } catch (err) {
      console.warn('IndexedDB initialization/migration failed', err);
    }

    const attach = (sel, ev, fn) => {
      const el = document.querySelector(sel);
      if (!el) { console.warn(`attach: element ${sel} not found; skipping ${ev}`); return; }
      el.addEventListener(ev, fn);
    };

    attach('#showAllBtn', 'click', () => {
      currentCategory = "All Items";
      const si = document.querySelector('#searchInput'); if (si) si.value = "";
      try { renderCategories(); renderProducts(); } catch(e) { console.error(e); }
    });

    attach('#historyBtn', 'click', () => { const d = document.querySelector('#historyDrawer'); if (d) d.style.display = 'block'; });
    attach('#closeHistory', 'click', () => { const d = document.querySelector('#historyDrawer'); if (d) d.style.display = 'none'; });
    attach('#adminToggle', 'click', () => { const panel = document.querySelector('#adminPanel'); if (!panel) return; panel.style.display = (panel.style.display === 'block') ? 'none' : 'block'; });
    attach('#clearBillBtn', 'click', () => { try { clearBill(); } catch(e) { console.error(e); } });

    attach('#printBtn', 'click', () => { try { printBill(); } catch(e) { console.error(e); } });

    // Payment modal handlers
    attach('#cancelPaymentBtn', 'click', closePaymentModal);
    attach('#confirmPaymentBtn', 'click', markAsPaid);
    
    attach('#cancelDeleteBtn', 'click', closeDeleteReasonModal);
    attach('#confirmDeleteBtn', 'click', deleteWithReason);

    if (document.querySelector('#adminLoginBtn')) attach('#adminLoginBtn', 'click', adminLogin);
    if (document.querySelector('#adminLogoutBtn')) attach('#adminLogoutBtn', 'click', adminLogout);
    if (document.querySelector('#addCategoryBtn')) attach('#addCategoryBtn', 'click', addCategory);
    if (document.querySelector('#addProductBtn')) attach('#addProductBtn', 'click', addProduct);
    if (document.querySelector('#addCustomProductBtn')) attach('#addCustomProductBtn', 'click', addCustomProduct);
    if (document.querySelector('#addDealBtn')) attach('#addDealBtn', 'click', addDeal);
    if (document.querySelector('#removeCategoryBtn')) attach('#removeCategoryBtn', 'click', removeCategory);
    if (document.querySelector('#removeProductBtn')) attach('#removeProductBtn', 'click', removeProduct);
    if (document.querySelector('#removeDealBtn')) attach('#removeDealBtn', 'click', removeDeal);
    if (document.querySelector('#showSalesBtn')) attach('#showSalesBtn', 'click', renderSalesReport);

    if (document.querySelector('#deleteSalesBtn')) attach('#deleteSalesBtn', 'click', deleteSalesAndHistory);
    if (document.querySelector('#printDeleteSalesBtn')) attach('#printDeleteSalesBtn', 'click', printAndDeleteSales);

    $$(".order-type").forEach(btn => btn.addEventListener('click', function(){ 
      orderType = this.dataset.ordertype; 
      $$(".order-type").forEach(b => b.classList.remove('active')); 
      this.classList.add('active'); 
      $("#addressWrap").style.display = (orderType === 'Delivery') ? 'block' : 'none'; 
    }));

    const nameEl = document.querySelector('#customerName');
    if (nameEl) nameEl.addEventListener('input', () => {
      const name = nameEl.value.trim();
      if (name && addressBook && addressBook.byName && addressBook.byName[name]){
        const rec = addressBook.byName[name];
        $("#customerPhone").value = rec.phone || "";
        $("#customerAddress").value = rec.address || "";
        $("#deliveryCharge").value = rec.deliveryCharge || "";
      }
    });

    const phoneEl = document.querySelector('#customerPhone');
    if (phoneEl) phoneEl.addEventListener('input', () => {
      const v = phoneEl.value.trim();
      if (v && addressBook && addressBook.byPhone && addressBook.byPhone[v]){
        const name = addressBook.byPhone[v];
        const rec = (addressBook.byName && addressBook.byName[name]) ? addressBook.byName[name] : null;
        if (rec){
          $("#customerName").value = name || "";
          $("#customerAddress").value = rec.address || "";
          $("#deliveryCharge").value = rec.deliveryCharge || "";
        } else {
          $("#customerAddress").value = "";
        }
      }
    });

    const disc = document.querySelector('#discount'); if (disc) disc.addEventListener('input', updateBill);
    const del = document.querySelector('#deliveryCharge'); if (del) del.addEventListener('input', updateBill);

    const backdrop = document.querySelector('#modalBackdrop');
    if (backdrop) backdrop.addEventListener('click', (e) => { if (e.target === backdrop) closeEditModal(); });

    populateAdminSelects();

    console.log('POS init complete â€” all enhancements loaded');
  } catch (err) {
    console.error('POS init error', err);
  }
});
function clearBill(){
  bill = []; updateBill();
  $("#customerName").value=''; $("#customerPhone").value=''; $("#customerAddress").value=''; $("#customerNote").value=''; $("#discount").value=''; $("#deliveryCharge").value='';
  orderType = ''; $$(".order-type").forEach(b => b.classList.remove('active')); $("#addressWrap").style.display = 'none';
}