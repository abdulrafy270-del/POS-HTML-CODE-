/* =========================
   IndexedDB + localStorage fallback
   ========================= */

const IDB_DB_NAME = 'ideal_food_db';
const IDB_DB_VERSION = 1;
let idbDb = null;

function idbOpen(){
  return new Promise((resolve, reject) => {
    if (idbDb) return resolve(idbDb);
    const req = indexedDB.open(IDB_DB_NAME, IDB_DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains('images')) db.createObjectStore('images', { keyPath: 'id', autoIncrement: true });
      if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta', { keyPath: 'key' });
    };
    req.onsuccess = (e) => { idbDb = e.target.result; resolve(idbDb); };
    req.onerror = (e) => reject(e.target.error);
  });
}

function idbPutImage(blob){
  return idbOpen().then(db => new Promise((resolve,reject) => {
    const tx = db.transaction('images','readwrite');
    const store = tx.objectStore('images');
    const req = store.add({ blob });
    req.onsuccess = () => resolve(req.result);
    req.onerror = (ev) => reject(ev.target.error);
  }));
}

function idbGetImage(id){
  return idbOpen().then(db => new Promise((resolve,reject) => {
    const tx = db.transaction('images','readonly');
    const store = tx.objectStore('images');
    const req = store.get(Number(id));
    req.onsuccess = () => {
      if (!req.result) return resolve(null);
      resolve(req.result.blob);
    };
    req.onerror = (ev) => reject(ev.target.error);
  }));
}

function idbSetMeta(key, value){
  return idbOpen().then(db => new Promise((resolve,reject) => {
    const tx = db.transaction('meta','readwrite');
    const store = tx.objectStore('meta');
    const req = store.put({ key, value });
    req.onsuccess = () => resolve();
    req.onerror = (ev) => reject(ev.target.error);
  }));
}

function idbGetMeta(key){
  return idbOpen().then(db => new Promise((resolve,reject) => {
    const tx = db.transaction('meta','readonly');
    const store = tx.objectStore('meta');
    const req = store.get(key);
    req.onsuccess = () => { resolve(req.result ? req.result.value : null); };
    req.onerror = (ev) => reject(ev.target.error);
  }));
}

/* =========================
   Storage keys and seeds
   ========================= */
const LS_KEYS = {
  PRODUCTS: "ideal_food_products",
  CATEGORIES: "ideal_food_categories",
  DEALS: "ideal_food_deals",
  HISTORY: "ideal_food_history",
  ADDRESS_BOOK: "ideal_food_address_book",
  SALES: "ideal_food_sales_daily",
  INVOICE_COUNTER: "ideal_food_invoice_counter",
  DELETION_LOG: "ideal_food_deletion_log"
};

const seedCategories = ["All Items", "Fast Food", "Healthy", "Beverages"];
const seedProducts = [
  { name: "Tikka Pizza", category: "Fast Food", price:{ small:450, medium:700, large:1100 }, img:"", priceList:[] },
  { name: "Zinger Burger", category: "Fast Food", price:{ small:270, medium:0, large:0 }, img:"", priceList:[] },
  { name: "Fresh Salad", category: "Healthy", price:{ small:100, medium:200, large:300 }, img:"", priceList:[] },
  { name: "Coke", category: "Beverages", price:{ small:50, medium:80, large:120 }, img:"", priceList:[] }
];

function lsGetSync(key, fallback){
  try {
    const raw = localStorage.getItem(key);
    if (raw === null) return fallback;
    return JSON.parse(raw);
  } catch (e) {
    console.warn('lsGetSync parse failed', key, e);
    return fallback;
  }
}

function lsSet(key, val){
  try {
    localStorage.setItem(key, JSON.stringify(val));
  } catch (e) {
    console.warn('localStorage.setItem failed for key', key, e, '— saving to IndexedDB meta instead.');
    idbSetMeta(key, val).catch(err => console.error('idbSetMeta failed', err));
  }
}

async function loadMetaFromIDB(){
  try {
    await idbOpen();
    for (const k of Object.values(LS_KEYS)){
      const v = await idbGetMeta(k);
      if (v !== null && v !== undefined){
        try { localStorage.setItem(k, JSON.stringify(v)); } catch(err) { /* ok */ }
        if (k === LS_KEYS.CATEGORIES) categories = v;
        if (k === LS_KEYS.PRODUCTS) products = v;
        if (k === LS_KEYS.DEALS) deals = v;
        if (k === LS_KEYS.HISTORY) historyData = v;
        if (k === LS_KEYS.ADDRESS_BOOK) addressBook = v;
        if (k === LS_KEYS.SALES) salesData = v;
        if (k === LS_KEYS.INVOICE_COUNTER) invoiceCounter = v;
        if (k === LS_KEYS.DELETION_LOG) deletionLog = v;
      }
    }
  } catch (e) { console.warn('loadMetaFromIDB failed', e); }
}